import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Shield, Activity, Bell, Brain, Users, Phone, Mail, Heart, ChevronRight, AlertTriangle, Check, X } from 'lucide-react';

function App() {
  const [demoVitals, setDemoVitals] = useState<{ time: string; heartRate: number }[]>([]);
  const [alerts, setAlerts] = useState<{ id: number; type: string; message: string; urgent: boolean }[]>([]);
  const [showDemo, setShowDemo] = useState(false);

  // Generate demo vital signs data
  useEffect(() => {
    const generateVitals = () => {
      const now = new Date();
      const newDataPoint = {
        time: now.toLocaleTimeString(),
        heartRate: 70 + Math.random() * 10
      };

      setDemoVitals(prev => [...prev.slice(-20), newDataPoint]);

      // Generate random alerts
      if (Math.random() < 0.1) {
        const newAlert = {
          id: Date.now(),
          type: Math.random() > 0.5 ? 'medication' : 'activity',
          message: Math.random() > 0.5 
            ? 'Time for blood pressure medication'
            : 'Unusual inactivity detected',
          urgent: Math.random() > 0.7
        };
        setAlerts(prev => [newAlert, ...prev].slice(0, 5));
      }
    };

    let interval: number;
    if (showDemo) {
      interval = setInterval(generateVitals, 2000);
    }

    return () => clearInterval(interval);
  }, [showDemo]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 text-white relative overflow-hidden">
        <motion.div 
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: "reverse"
          }}
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
            backgroundSize: 'cover',
          }}
        />
        
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between relative z-10">
          <motion.div 
            className="flex items-center space-x-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Shield className="w-8 h-8" />
            <span className="text-xl font-bold">SAIFEGuard</span>
          </motion.div>
          <div className="hidden md:flex space-x-8">
            <a href="#features" className="hover:text-blue-200 transition">Features</a>
            <a href="#demo" className="hover:text-blue-200 transition">Live Demo</a>
            <a href="#how-it-works" className="hover:text-blue-200 transition">How It Works</a>
            <a href="#contact" className="hover:text-blue-200 transition">Contact</a>
          </div>
        </nav>
        
        <div className="container mx-auto px-6 py-20 relative z-10">
          <motion.div 
            className="max-w-3xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              The Future of Elderly Care is Here
            </h1>
            <p className="text-xl mb-8 text-blue-100">
              Experience our revolutionary multi-agent AI system providing 24/7 care, 
              support, and peace of mind for elderly individuals and their families.
            </p>
            <motion.button 
              className="bg-white text-blue-700 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition flex items-center text-lg shadow-lg"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowDemo(true)}
            >
              Try Live Demo
              <ChevronRight className="ml-2 w-6 h-6" />
            </motion.button>
          </motion.div>
        </div>
      </header>

      {/* Live Demo Section */}
      <section id="demo" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Live System Demo</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Vitals Monitoring */}
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold">Real-time Vitals Monitor</h3>
                <Heart className="w-6 h-6 text-red-500" />
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={demoVitals}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[60, 90]} />
                    <Tooltip />
                    <Line 
                      type="monotone" 
                      dataKey="heartRate" 
                      stroke="#2563eb" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <button 
                className="mt-4 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
                onClick={() => setShowDemo(!showDemo)}
              >
                {showDemo ? 'Stop Demo' : 'Start Demo'}
              </button>
            </div>

            {/* AI Alerts */}
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold">AI Agent Alerts</h3>
                <AlertTriangle className="w-6 h-6 text-yellow-500" />
              </div>
              <div className="space-y-4">
                {alerts.map(alert => (
                  <motion.div 
                    key={alert.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`p-4 rounded-lg flex items-start space-x-4 ${
                      alert.urgent ? 'bg-red-50' : 'bg-blue-50'
                    }`}
                  >
                    {alert.urgent ? (
                      <X className="w-5 h-5 text-red-500 mt-1" />
                    ) : (
                      <Check className="w-5 h-5 text-blue-500 mt-1" />
                    )}
                    <div>
                      <p className={`font-medium ${
                        alert.urgent ? 'text-red-700' : 'text-blue-700'
                      }`}>
                        {alert.type === 'medication' ? 'Medication Alert' : 'Activity Alert'}
                      </p>
                      <p className="text-sm text-gray-600">{alert.message}</p>
                    </div>
                  </motion.div>
                ))}
                {alerts.length === 0 && (
                  <p className="text-gray-500 text-center py-8">No active alerts</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Intelligent Care Agents</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div whileHover={{ scale: 1.05 }}>
              <FeatureCard
                icon={<Activity className="w-8 h-8 text-blue-600" />}
                title="Health Monitor"
                description="24/7 vital sign monitoring with AI-powered anomaly detection for proactive health management."
              />
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }}>
              <FeatureCard
                icon={<Bell className="w-8 h-8 text-blue-600" />}
                title="Smart Alerts"
                description="Contextual notification system for medications, appointments, and daily activities."
              />
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }}>
              <FeatureCard
                icon={<Brain className="w-8 h-8 text-blue-600" />}
                title="Behavioral Analysis"
                description="Advanced pattern recognition for detecting unusual changes in daily routines."
              />
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }}>
              <FeatureCard
                icon={<Users className="w-8 h-8 text-blue-600" />}
                title="Caregiver Connect"
                description="Real-time communication platform between elderly individuals, family, and healthcare providers."
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">How SAIFEGuard Works</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <ProcessCard
                number="01"
                title="Smart Integration"
                description="Seamlessly connects with wearables and smart home devices for comprehensive monitoring."
              />
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              <ProcessCard
                number="02"
                title="AI-Powered Analysis"
                description="Multiple AI agents work together to analyze data and make intelligent decisions."
              />
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
            >
              <ProcessCard
                number="03"
                title="Proactive Care"
                description="Delivers timely interventions and alerts before issues become emergencies."
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-blue-50">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold mb-8">Ready to Transform Elderly Care?</h2>
              <p className="text-gray-600 mb-8">
                Contact us to learn more about how SAIFEGuard can revolutionize care for your loved ones.
              </p>
              <div className="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-8">
                <motion.a 
                  href="tel:+1234567890" 
                  className="flex items-center text-blue-600 hover:text-blue-700 bg-white px-6 py-3 rounded-lg shadow-md hover:shadow-lg transition"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Phone className="w-5 h-5 mr-2" />
                  (123) 456-7890
                </motion.a>
                <motion.a 
                  href="mailto:info@saifeguard.com" 
                  className="flex items-center text-blue-600 hover:text-blue-700 bg-white px-6 py-3 rounded-lg shadow-md hover:shadow-lg transition"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Mail className="w-5 h-5 mr-2" />
                  info@saifeguard.com
                </motion.a>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Shield className="w-6 h-6" />
              <span className="text-lg font-bold">SAIFEGuard</span>
            </div>
            <div className="text-sm text-gray-400">
              © 2025 SAIFEGuard. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition h-full">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function ProcessCard({ number, title, description }: { number: string; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition h-full">
      <div className="text-3xl font-bold text-blue-600 mb-4">{number}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

export default App;